import decimal
import iris._DBList

class _ListWriter(object):

	CHUNKSIZE = 256

	def __init__(self, locale = "latin-1", is_unicode = True):
		self.buffer = bytearray(_ListWriter.CHUNKSIZE)
		self.offset = 0
		self._locale = locale
		self._is_unicode = is_unicode

	def _set(self, data):
		self.__check_buffer_size(self.__estimate_size(data))
		self.offset = iris._DBList._set(self.buffer, self.offset, data, self._locale, self._is_unicode)
		return

	def _set_undefined(self):
		self.__check_buffer_size(1)
		self.offset = iris._DBList._set_undefined(self.buffer, self.offset)

	def _set_null(self):
		self.__check_buffer_size(2)
		self.offset = iris._DBList._set_null(self.buffer, self.offset)

	def _set_raw_bytes(self, data):
		length = len(data)
		self.__check_buffer_size(length)
		self.buffer[self.offset:self.offset+length] = data[0:length]
		self.offset = self.offset + length
		return

	def _size(self):
		return self.offset

	def _get_buffer(self):
		return self.buffer[0:self.offset]

	def __estimate_size(self, data):
		switcher = {
			type(None): 2,
			bool: 3,
			int: 10,
			float: 10,
			decimal.Decimal: 11
		}
		if type(data) == int and (data > 0x7fffffffffffffff or data < -0x8000000000000000):
			data = str(data)
		if type(data) is str or type(data) is bytes or type(data) is bytearray:
			estimated = len(data)*2+8
		else:
			estimated = switcher.get(type(data), 0)
		return estimated

	def __check_buffer_size(self, additional):
		if self.offset + additional > len(self.buffer):
			size_needed = self.offset + additional
			size_to_allocate = len(self.buffer)*2
			while True:
				if size_to_allocate > size_needed:
					break
				size_to_allocate = size_to_allocate*2
			new_buffer = bytearray(size_to_allocate)
			new_buffer[0:len(self.buffer)] = self.buffer
			self.buffer = new_buffer
		return

	def _save_current_offset(self):
		self.__saved_offset = self.offset
		return

	def _set_saved_offset_type_as_pass_by_reference(self):
		iris._DBList._set_type_as_pass_by_reference(self.buffer, self.__saved_offset)
		return
