import sys
import importlib

def loadmodule(iris_installation_dir):
	is_64bits = sys.maxsize > 2**32
	if sys.platform.startswith('win32'):
		if (is_64bits):
			iris_installation_dir = iris_installation_dir + r"bin"
			sys.path.append(iris_installation_dir)
			mod = importlib.import_module("XDEVshm")
		else:
			iris_installation_dir = iris_installation_dir + r"bin"
			sys.path.append(iris_installation_dir)
			mod = importlib.import_module("XDEVshm32")
	else:
		iris_installation_dir = iris_installation_dir + r"bin"
		sys.path.append(iris_installation_dir)
		mod = importlib.import_module("libxdevshm")
	return mod

def init(mod,pid,filename,flag):
	return mod.shm_initshm(int(pid),filename,flag)

def close(mod,shmRef):
	return mod.shm_close(shmRef)

def connect(mod,shmRef,timeout):
	return mod.shm_connect(shmRef,timeout)

def sendall(mod,shmRef,buff):
	return mod.shm_sendall(shmRef,buff)

def recv(mod,shmRef,len):
	return mod.shm_recv(shmRef,len)