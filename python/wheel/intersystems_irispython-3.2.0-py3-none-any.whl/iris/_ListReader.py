import iris._DBList
import iris._ListItem

class _ListReader(object):

	def __init__(self, bufferarray, locale = "latin-1"):
		self.list_item = iris._ListItem(bufferarray)
		self._locale = locale

	def _get(self, asBytes = False):
		iris._DBList._get_list_element(self.list_item)
		return iris._DBList._get(self.list_item, self._locale, asBytes)
	
	def _get_raw_bytes(self, length):
		self.is_null = False
		self.list_item.type = iris._DBList.ITEM_PLACEHOLDER
		self.list_item.data_offset = 0
		self.list_item.data_length = 0
		self.list_item.next_offset = self.list_item.next_offset + length
		return self.list_item.buffer[self.list_item.next_offset-length:self.list_item.next_offset]

	def _is_end(self):
		return (self.list_item.next_offset >= self.list_item.list_buffer_end)



