import base64
import getpass
import os
import platform
import socket
import struct
import sys
import threading
import iris._SharedMemorySocketImpl

class _SharedMemorySocket(object):

	def __init__(self,iris_installation_dir,pid,filename,flag):
		self.mod = iris._SharedMemorySocketImpl.loadmodule(iris_installation_dir)
		self.shmRef = 0
		self.shmRef = iris._SharedMemorySocketImpl.init(self.mod,pid,filename,flag)
		if (self.shmRef==0):
			raise Exception("Could not create shared memory")

	def close(self):
		status = iris._SharedMemorySocketImpl.close(self.mod,self.shmRef)
		if (status==0):
			self.shmRef=0
		else:
			raise Exception("Could not close shared memory")

	def settimeout(self,time):
		return

	def connect(self,timeout):
		return iris._SharedMemorySocketImpl.connect(self.mod,self.shmRef,timeout)

	def sendall(self, buff):
		return iris._SharedMemorySocketImpl.sendall(self.mod,self.shmRef,buff)

	def recv(self, len):
		return iris._SharedMemorySocketImpl.recv(self.mod,self.shmRef,len)

	def gethostname(self):
		return ""

	def gethostbyname(self, hostname):
		return ""