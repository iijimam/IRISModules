class _ConnectionParameters(object):
	"""_ConnectionParameters represents the properties that are implicit to a URL."""
	def __init__(self):
		self.hostname = ""
		self.port = ""
		self.namespace = ""
		self.timeout = ""
		self.sharedmemory = False
		self.logfile = ""

	def updateconnectinput(self, hostname, port, namespace, timeout, sharedmemory, logfile):
		self.hostname = hostname
		self.port = port
		self.namespace = namespace
		self.timeout = timeout
		self.sharedmemory = sharedmemory
		self.logfile = logfile

